Modify Student to be composed of an Address but not inherit from an Address.

A Student is not an Address.

Main does not have to be modified.