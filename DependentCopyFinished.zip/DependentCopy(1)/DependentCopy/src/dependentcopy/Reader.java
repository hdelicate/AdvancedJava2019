package dependentcopy;

public interface Reader {
    public abstract String readln();
}
