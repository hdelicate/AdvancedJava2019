package dependentcopy;

public interface Writer {
    public abstract void writeln( String line );
}
