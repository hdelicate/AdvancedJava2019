Instructions for IndependentCopy Project:
===========================================

The UML diagram cannot be openend from within Netbeans. Please go to the
file system and double-click on it to open it in a Windows Graphics viewer.
