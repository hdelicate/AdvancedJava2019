package isp.lab1;

public interface Workable {

    public void talk(String s);
    public void jump();
    public void hike();
    public void swim();
    public void trip();

}
