package isp.lab1.student;

public interface IVehicle {
}
