package isp.lab1;

public interface IVehicle {
    public void run(int distance);
    public void start();
    public void drive(int distance);
    public void stopByBreaking();
}
