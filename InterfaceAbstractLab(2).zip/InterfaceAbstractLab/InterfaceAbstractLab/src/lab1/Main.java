package lab1;

import java.util.Scanner;

public class Main  {
        public static void main(String[] args) {
        MyAbstractSuperClass advanced = new AdvancedJavaCourse("124","Advanced Java", 3, "Intro");
            MyAbstractSuperClass intro = new IntroJavaCourse("114","Intro Java", 2 );
            MyAbstractSuperClass introProg = new IntroToProgrammingCourse("114","Intro Programming", 2 );




    }
}
