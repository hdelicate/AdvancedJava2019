package lab1;

import javax.swing.JOptionPane;

/**
 * Describe responsibilities here.
 *
 * @author      your name goes here
 * @version     1.00
 */
public class AdvancedJavaCourse extends MyAbstractSuperClass {
    public AdvancedJavaCourse(String courseNumber, String courseName, double credits, String prerquisites){
        this.courseName = courseName;
        this.courseNumber = courseNumber;
        this.credits = credits;
        this.prerequisites = prerquisites;

    }
    
}
