package lab1;

/**
 * Describe responsibilities here.
 *
 * @author      your name goes here
 * @version     1.00
 */
public class IntroJavaCourse extends MyAbstractSuperClass {
    public IntroJavaCourse(String courseNumber, String courseName, double credits){
        this.courseName = courseName;
        this.courseNumber = courseNumber;
        this.credits = credits;

    }

}
