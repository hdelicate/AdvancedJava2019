package lab1;

import javax.swing.JOptionPane;

/**
 * Describe responsibilities here. NOTE: this class has NO PREREQUISITES!
 * Do not change this fact.
 *
 * @author      your name goes here
 * @version     1.00
 */
public class IntroToProgrammingCourse extends MyAbstractSuperClass {

   public IntroToProgrammingCourse(String courseNumber, String courseName, double credits){
       this.courseName = courseName;
       this.courseNumber = courseNumber;
       this.credits = credits;

    }
}
