package lab2;

public class Main {
    public static void main(String[] args) {
        AdvancedJavaCourse advanced = new AdvancedJavaCourse("124", "Advanced Java", 3, "Intro");
        IntroToProgrammingCourse intro = new IntroToProgrammingCourse("114", "Intro Java", 2);
        IntroJavaCourse introProg = new IntroJavaCourse("Intro Java", "132", 2);
    }
}
