package lab2;

import javax.swing.*;

public interface MyInterface {
   public String getCourseName();
   public void setCourseName(String courseName);
    public String getCourseNumber();
    public void setCourseNumber(String courseNumber);
    public double getCredits();
    public void setCredits(double credits);

}
