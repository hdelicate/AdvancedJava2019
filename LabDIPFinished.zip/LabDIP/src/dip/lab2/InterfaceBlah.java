public interface InterfaceBlah {
    public enum ServiceQuality {
        GOOD, FAIR, POOR
    }
  public abstract double getTips();
    public abstract void setServiceRating(ServiceQuality q);

    public abstract ServiceQuality getServiceQuality();


}
