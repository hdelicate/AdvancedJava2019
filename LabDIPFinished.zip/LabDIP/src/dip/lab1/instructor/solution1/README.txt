This is just one solution to the problem posed in "dip.lab1".
There are other ways to satisfy the DIP requirement. Please read ALL
of the comments carefully and ask questions if you don't understand
something.